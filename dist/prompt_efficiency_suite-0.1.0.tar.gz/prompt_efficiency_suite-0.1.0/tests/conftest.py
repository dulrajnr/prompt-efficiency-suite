import pytest
from prompt_efficiency_suite import (
    DomainAwareTrimmer,
    AdaptiveBudgeting,
    CICDIntegration
)

@pytest.fixture
def domain_aware_trimmer():
    return DomainAwareTrimmer()

@pytest.fixture
def adaptive_budgeting():
    return AdaptiveBudgeting()

@pytest.fixture
def cicd_integration():
    return CICDIntegration() 