"""
Test suite for the CLI module.
"""

import pytest
from click.testing import CliRunner
from pathlib import Path
import json
import tempfile
from prompt_efficiency_suite.cli import cli, load_config

@pytest.fixture
def runner():
    """Create a CLI runner."""
    return CliRunner()

@pytest.fixture
def sample_config():
    """Create a sample configuration."""
    return {
        'monitoring_interval': 60,
        'thresholds': {
            'gpt-4': {
                'max_tokens': 1000000,
                'max_cost': 100.0
            }
        }
    }

@pytest.fixture
def temp_config_file(sample_config):
    """Create a temporary configuration file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(sample_config, f)
        return f.name

def test_load_config(temp_config_file):
    """Test loading configuration file."""
    config = load_config(Path(temp_config_file))
    assert config['monitoring_interval'] == 60
    assert 'gpt-4' in config['thresholds']

def test_load_invalid_config():
    """Test loading invalid configuration file."""
    with pytest.raises(Exception):
        load_config(Path('nonexistent.json'))

def test_trim_text(runner, temp_config_file):
    """Test text trimming command."""
    # Create temporary input and output files
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as input_file:
        input_file.write("This is a test text with some domain terms.")
        input_path = input_file.name
        
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as output_file:
        output_path = output_file.name
        
    # Create temporary domain dictionary
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as domain_file:
        json.dump({
            'terms': ['test', 'domain'],
            'compound_terms': [],
            'preserve_patterns': [],
            'remove_patterns': []
        }, domain_file)
        domain_path = domain_file.name
        
    # Run command
    result = runner.invoke(cli, [
        'trim', 'trim-text',
        input_path,
        output_path,
        '--domain', domain_path,
        '--config', temp_config_file
    ])
    
    assert result.exit_code == 0
    assert "Trimming Results" in result.output

def test_show_metrics(runner, temp_config_file):
    """Test showing budget metrics."""
    result = runner.invoke(cli, [
        'budget', 'show-metrics',
        '--config', temp_config_file
    ])
    
    assert result.exit_code == 0
    assert "Budget Metrics" in result.output

def test_reset_metrics(runner, temp_config_file):
    """Test resetting budget metrics."""
    result = runner.invoke(cli, [
        'budget', 'reset-metrics',
        '--config', temp_config_file,
        '--model', 'gpt-4'
    ])
    
    assert result.exit_code == 0
    assert "Reset metrics for model: gpt-4" in result.output

def test_run_tests(runner, temp_config_file):
    """Test running test suite."""
    result = runner.invoke(cli, [
        'cicd', 'run-tests',
        '--config', temp_config_file
    ])
    
    assert result.exit_code == 0
    assert "Test Results" in result.output

def test_deploy(runner, temp_config_file):
    """Test deploying package."""
    result = runner.invoke(cli, [
        'cicd', 'deploy',
        '--config', temp_config_file,
        '--target', 'pypi'
    ])
    
    assert result.exit_code == 0
    assert "Deployment Results" in result.output

def test_invalid_command(runner):
    """Test invalid command."""
    result = runner.invoke(cli, ['invalid-command'])
    assert result.exit_code != 0

def test_help(runner):
    """Test help command."""
    result = runner.invoke(cli, ['--help'])
    assert result.exit_code == 0
    assert "Prompt Efficiency Suite" in result.output 