import pytest
from prompt_efficiency_suite.model_translator import ModelTranslator, ModelType, ModelConfig

@pytest.fixture
def translator():
    return ModelTranslator()

def test_model_configs_loaded(translator):
    """Test that model configurations are properly loaded."""
    assert ModelType.GPT4 in translator.model_configs
    assert ModelType.CLAUDE in translator.model_configs
    
    gpt4_config = translator.model_configs[ModelType.GPT4]
    assert isinstance(gpt4_config, ModelConfig)
    assert gpt4_config.max_tokens > 0
    assert gpt4_config.cost_per_1k_tokens > 0

def test_style_patterns_loaded(translator):
    """Test that style patterns are properly loaded."""
    assert "concise" in translator.style_patterns
    assert "detailed" in translator.style_patterns
    
    concise_patterns = translator.style_patterns["concise"]
    assert "remove_redundant" in concise_patterns
    assert "simplify_phrases" in concise_patterns
    assert "replace_with" in concise_patterns

def test_translate_prompt_basic(translator):
    """Test basic prompt translation."""
    prompt = "This is a test prompt."
    translated = translator.translate_prompt(
        prompt=prompt,
        source_model=ModelType.GPT4,
        target_model=ModelType.CLAUDE,
        preserve_style=True
    )
    
    assert isinstance(translated, str)
    assert len(translated) > 0

def test_translate_prompt_style_adaptation(translator):
    """Test prompt translation with style adaptation."""
    prompt = "This is a really very extremely important test."
    translated = translator.translate_prompt(
        prompt=prompt,
        source_model=ModelType.GPT4,
        target_model=ModelType.CLAUDE,
        preserve_style=False
    )
    
    # Check if redundant words were removed
    assert "really" not in translated
    assert "very" not in translated
    assert "extremely" not in translated

def test_translate_prompt_format_adaptation(translator):
    """Test prompt translation with format adaptation."""
    prompt = "system: You are a helpful assistant.\nuser: Hello!"
    translated = translator.translate_prompt(
        prompt=prompt,
        source_model=ModelType.GPT4,
        target_model=ModelType.CLAUDE,
        preserve_style=True
    )
    
    # Check if format was adapted for Claude
    assert "Human:" in translated
    assert "Assistant:" in translated

def test_compare_models(translator):
    """Test model comparison functionality."""
    prompt = "This is a test prompt."
    models = [ModelType.GPT4, ModelType.CLAUDE]
    
    results = translator.compare_models(prompt, models)
    
    assert ModelType.GPT4 in results
    assert ModelType.CLAUDE in results
    
    for model in models:
        model_results = results[model]
        assert "estimated_tokens" in model_results
        assert "estimated_cost" in model_results
        assert "style_compatibility" in model_results
        assert "format_compatibility" in model_results

def test_get_model_specifics(translator):
    """Test getting model-specific configurations."""
    config = translator.get_model_specifics(ModelType.GPT4)
    
    assert isinstance(config, ModelConfig)
    assert config.max_tokens > 0
    assert config.cost_per_1k_tokens > 0
    assert isinstance(config.preferred_style, str)
    assert isinstance(config.temperature_range, tuple)
    assert isinstance(config.stop_sequences, list)
    assert isinstance(config.special_tokens, dict)

def test_invalid_model_type(translator):
    """Test handling of invalid model types."""
    with pytest.raises(ValueError):
        translator.translate_prompt(
            prompt="Test",
            source_model="invalid_model",
            target_model=ModelType.GPT4
        )

def test_token_optimization(translator):
    """Test token optimization functionality."""
    prompt = "This is a very long prompt that needs to be optimized for token usage."
    max_tokens = 10
    
    optimized = translator._optimize_tokens(prompt, max_tokens)
    
    assert isinstance(optimized, str)
    assert len(optimized.split()) <= max_tokens

def test_style_compatibility_calculation(translator):
    """Test style compatibility calculation."""
    prompt = "This is a test prompt."
    config = translator.get_model_specifics(ModelType.GPT4)
    
    compatibility = translator._calculate_style_compatibility(prompt, config)
    
    assert isinstance(compatibility, float)
    assert 0 <= compatibility <= 1

def test_format_compatibility_calculation(translator):
    """Test format compatibility calculation."""
    prompt = "This is a test prompt."
    config = translator.get_model_specifics(ModelType.GPT4)
    
    compatibility = translator._calculate_format_compatibility(prompt, config)
    
    assert isinstance(compatibility, float)
    assert 0 <= compatibility <= 1 